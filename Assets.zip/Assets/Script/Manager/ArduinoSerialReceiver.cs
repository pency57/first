using System.Collections.Concurrent;
using System.IO.Ports;
using System.Threading;
using UnityEngine;
using System;

public class ArduinoSerialReceiver : MonoBehaviour
{
    public static ArduinoSerialReceiver Instance { get; set; } // 싱글톤

    SerialPort serialPort;
    Thread serialThread;
    bool isRunning = false;

    [SerializeField] string portName = "COM5";
    [SerializeField] int baudRate = 115200;

    // 센서 값 저장
    public bool TouchSensorOne { get; set; }
    public bool TouchSensorTwo { get; set; }
    public bool TouchSensorThree { get; set; }
    public bool TouchSensorFour { get; set; }
    public bool PaddleSensor { get; set; }
    public bool WhammyBar { get; set; } // 와미 바 센서 (0/1 값)

    // PaddleSensor의 이전 상태와 이벤트
    public bool previousPaddleSensorState = false;
    public bool paddleSensorPressed = false;

    public bool previousWhammyBarState = false;
    public bool WhammyBarPressed = false;

    // 스레드와 메인 스레드 간 데이터 공유
    ConcurrentQueue<string> dataQueue = new ConcurrentQueue<string>();

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // 씬 전환 시 객체 유지
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        StartSerialThread();
    }

    void StartSerialThread()
    {
        try
        {
            serialPort = new SerialPort(portName, baudRate);
            serialPort.ReadTimeout = 20; // 읽기 타임아웃 설정
            serialPort.Open();

            if (serialPort.IsOpen)
            {
                isRunning = true;
                serialThread = new Thread(SerialReadLoop);
                serialThread.Start();
                Debug.Log("Serial thread started successfully.");
            }
            else
            {
                Debug.LogError("Failed to open the serial port.");
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to start serial thread: {ex.Message}");
        }
    }

    void SerialReadLoop()
    {
        while (isRunning) {  // isRunning이 false로 설정될 때 스레드가 종료됨
            try {
                if (serialPort.BytesToRead > 0) {
                    string receivedData = serialPort.ReadLine();
                    // 데이터를 큐에 추가
                    dataQueue.Enqueue(receivedData);  
                }
            }
            catch (TimeoutException) {
                Debug.LogWarning("Read Timeout");
            }
            catch (Exception ex)
            {
                Debug.LogError("Error reading data: " + ex.Message);
            }
        }
    }

    void Update()
    {
        // 큐에서 데이터를 꺼내 처리
        while (dataQueue.TryDequeue(out string input))
        {
            ParseInputData(input); // 데이터 파싱
        }

        if (!Application.isPlaying)
        {
            StopSerialThread();
        }
    }

    void ParseInputData(string input)
    {
        if (input.Length == 6 && int.TryParse(input, out _)) // 입력값이 항상 6자리인지 확인
        {
            paddleSensorPressed = input[0] != '1';
            WhammyBarPressed = input[1] != '1';
            TouchSensorOne = input[2] != '1';
            TouchSensorTwo = input[3] != '1';
            TouchSensorThree = input[4] != '1';
            TouchSensorFour = input[5] != '1';

            /* // PaddleSensor 상태 변화 감지
            paddleSensorPressed = !previousPaddleSensorState && currentPaddleSensorState; // 눌림 이벤트
            previousPaddleSensorState = currentPaddleSensorState; // 상태 업데이트

            PaddleSensor = currentPaddleSensorState; // PaddleSensor 현재 상태

            WhammyBarPressed = !previousWhammyBarState && currentWhammyBarState; // 눌림 이벤트
            previousWhammyBarState = currentWhammyBarState; // 상태 업데이트

            WhammyBar = currentWhammyBarState; // WhammyBar 현재 상태
            // 데이터 출력 */
        }
        else
        {
            Debug.LogWarning($"Invalid data received: {input}");
        }
    }
/* 
    bool GetPaddleSensorDown()
    {
        if (paddleSensorPressed)
        {
            paddleSensorPressed = false; // 이벤트를 한 번만 발생시키기 위해 리셋
            return true;
        }
        return false;
    } */

    void OnDestroy()
    {
        StopSerialThread();
    }

    void OnApplicationQuit()
    {
        StopSerialThread();
    }

    void StopSerialThread()
    {
        isRunning = false;
        try
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Error closing serial port: {ex.Message}");
        }

        serialThread?.Join();
    }
}

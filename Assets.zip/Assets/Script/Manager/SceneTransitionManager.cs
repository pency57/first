using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransitionManager : MonoBehaviour
{
    // 패들 센서를 감지하는 변수
    private bool isPaddleSensorActive;

    private void Update()
    {
        Time.timeScale = 1;
        // ArduinoSerialReceiver에서 패들 센서 값 가져오기
        if (ArduinoSerialReceiver.Instance != null)
        {
            isPaddleSensorActive = ArduinoSerialReceiver.Instance.WhammyBarPressed;

            // 패들 센서가 활성화되면 곡 선택 씬으로 전환
            if (isPaddleSensorActive)
            {
                // 씬 전환 함수 호출
                LoadSongSelectionScene();
            }
        }
    }

    // 곡 선택 씬으로 전환하는 함수
    private void LoadSongSelectionScene()
    {
        // "SongSelectionScene"을 원하는 씬 이름으로 변경하세요.
        SceneManager.LoadScene("SongSelectionScene");
    }
}
/* using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransitionManager : MonoBehaviour
{
    // 패들 센서를 감지하는 변수
    private bool isPaddleSensorActive;

    private void Update()
    {
            Time.timeScale = 1;
            isPaddleSensorActive = Input.GetKeyDown(KeyCode.Space);

            // 패들 센서가 활성화되면 곡 선택 씬으로 전환
            if (isPaddleSensorActive)
            {
                // 씬 전환 함수 호출
                LoadSongSelectionScene();
            }

    }

    // 곡 선택 씬으로 전환하는 함수
    private void LoadSongSelectionScene()
    {
        // "SongSelectionScene"을 원하는 씬 이름으로 변경하세요.
        SceneManager.LoadScene("SongSelectionScene");
    }
} */


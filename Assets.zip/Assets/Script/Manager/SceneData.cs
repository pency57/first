using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class SceneData
{
    public static string SongName;
    public static string MusicClip;
    public static string FileName;
    public static int MaxScore;
    public static float NoteSpeed;
    public static float OffSet;
    public static float StartT;
    public static int EndT;

}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Data;
using TMPro;
using SQLite;

public class Leaderboard : MonoBehaviour
{
    private string dbPath;
    public TMP_Text leaderboardText; // UI Text에 연결될 TMP_Text 변수
    private string currentSong;

    void Start()
    {
        dbPath = Application.persistentDataPath + "/RecordData.sqlite";
        Debug.Log($"Database Path: {dbPath}");
        ShowLeaderboard(SceneData.SongName);
    }

    void Update()
    {
        // SceneData.SongName이 바뀌었는지 확인
        if (currentSong != SceneData.SongName)
        {
            currentSong = SceneData.SongName; // 현재 곡 업데이트
            ShowLeaderboard(currentSong);    // 순위표 업데이트
        }
    }

    void ShowLeaderboard(string music)
    {
        if (leaderboardText == null)
        {
            Debug.LogError("TMP_Text is not assigned to leaderboardText.");
            return;
        }

        // SQLite 연결 설정
        using (var connection = new SQLiteConnection(dbPath)) // SQLite-net에서는 Open() 메서드가 필요 없음
        {
            // SQL 쿼리 (점수 내림차순으로 정렬)
            string query = "SELECT Nickname, Total_score FROM ScoreEntry WHERE Music = ? ORDER BY Total_score DESC";

            // Execute SQL query using SQLite-net
            var leaderboard = connection.Query<LeaderboardEntry>(query, music); // 쿼리 실행 후 데이터를 가져옵니다.
            Debug.Log($"여기까지 실행");

            leaderboardText.text = "순위\n";
            int rank = 1; // 1등부터 시작
            foreach (var entry in leaderboard)
            {
                if (rank > 20) break; // 최대 15명까지만 표시
                leaderboardText.text += $"{rank}. {entry.Nickname}   {entry.Total_score}\n";
                rank++;
            }

            if (rank == 1) // 데이터가 없는 경우
            {
                leaderboardText.text = "No data available.";
            }

        }
    }

    // LeaderboardEntry 클래스를 사용하여 데이터를 가져옵니다.
    public class LeaderboardEntry
    {
        public string Nickname { get; set; }
        public int Total_score { get; set; }
    }
}

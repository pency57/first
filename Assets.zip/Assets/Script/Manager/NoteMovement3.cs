using UnityEngine;
using System.Collections;
using TMPro;

public class NoteMovement3 : MonoBehaviour
{
    public float speed; // 노트 내려오는 속도
    public float height;
    public float xpos;
    public int hits;
    private int remainhits;

    private TextMeshPro textMesh;
    private SpriteRenderer spriteRenderer; // 색상 변경을 위한 SpriteRenderer
    private Color originalColor; // 원래 색상
    private bool isJudging = false;  // 판정 중인지 확인하는 변수

    void Start()
    {
        remainhits = hits;

        // SpriteRenderer 가져오기
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null)
        {
            originalColor = spriteRenderer.color; // 초기 색상 저장
        }
        else
        {
            Debug.LogError("SpriteRenderer가 이 오브젝트에 없습니다!");
        }
    }

    private void Update()
    {
        // 자식 중 텍스트 오브젝트를 찾아서 값 변경
        foreach (Transform child in transform)
        {
            if (child.name == "HitText")
            {
                textMesh = child.GetComponent<TextMeshPro>();
                if (textMesh != null)
                {
                    textMesh.text = remainhits.ToString(); // 텍스트를 noteValue로 설정
                }
                break;
            }
        }

        // 아래로 이동
        transform.Translate(Vector3.down * speed * Time.deltaTime);

        // 화면 아래로 사라지면 삭제
        if (transform.position.y < -18f - height / 2 || remainhits <= 0)
        {
            if (remainhits > 0)
            {
                if (remainhits * 100 / hits <= 15)
                {
                    ScoreManager.Instance.ProcessJudgment("Great");
                }
                else if (remainhits * 100 / hits <= 30)
                {
                    ScoreManager.Instance.ProcessJudgment("Good");
                }
                else if (remainhits * 100 / hits <= 50)
                {
                    ScoreManager.Instance.ProcessJudgment("Bad");
                }
                else
                {
                    ScoreManager.Instance.ProcessMiss();
                }
            }
            else
            {
                ScoreManager.Instance.ProcessJudgment("Perfect");
            }
            Destroy(gameObject);
        }

        if (remainhits > 0)
        {
            if (xpos == -6.75f) // Q 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorOne && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    StartCoroutine(HandleNoteJudgementWithDelay());
                }
            }
            else if (xpos == -2.25f) // W 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorTwo && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    StartCoroutine(HandleNoteJudgementWithDelay());
                }
            }
            else if (xpos == 2.25f) // E 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorThree && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    StartCoroutine(HandleNoteJudgementWithDelay());
                }
            }
            else if (xpos == 6.75f) // R 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorFour && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    StartCoroutine(HandleNoteJudgementWithDelay());
                }
            }
        }
    }

    private IEnumerator HandleNoteJudgementWithDelay()
    {
        if (isJudging) yield break;  // 이미 판정 중이면 중복 실행 방지

        isJudging = true;

        float yPos = transform.position.y;

        if (Mathf.Abs(yPos + 14.4f) <= 0.05f * speed + height / 2)
        {
            remainhits -= 1; // 연타 판정 처리
            ScoreManager.Instance.ProcessJudgment("Hit");

            // 색상 변경 코루틴 호출
            if (spriteRenderer != null)
            {
                StartCoroutine(ChangeColorTemporarily(new Color(1f, 0.4f, 0.4f), 0.05f)); // 색상과 지속 시간 설정
            }
        }

        // 딜레이를 0.03초 추가
        yield return new WaitForSeconds(0.10f);
    
        isJudging = false;
    }

    private IEnumerator ChangeColorTemporarily(Color newColor, float duration)
    {
        // 색상 변경
        spriteRenderer.color = newColor;

        // 지정된 시간 동안 대기
        yield return new WaitForSeconds(duration);

        // 원래 색상으로 복구
        spriteRenderer.color = originalColor;
    }
}

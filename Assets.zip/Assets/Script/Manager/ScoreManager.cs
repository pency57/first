using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance;

    public int score = 0;
    public int combo = 0;
    private int maxscore = SceneData.MaxScore;
    public int maxcombo;
    public uint gamescore;
    public int perfect_cnt = 0;
    public int great_cnt = 0;
    public int good_cnt = 0;
    public int bad_cnt = 0;
    public int miss_cnt = 0;
    private int endtime = SceneData.EndT;
    private string songname = SceneData.SongName;
    public OsuManiaNoteSpawner spawner;

    private TextMeshPro textMesh;
    private TextMeshPro textMesh2;
    public GameObject ResultPanel;
    public TextMeshProUGUI ResultText;
    public TextMeshProUGUI JudgmentText; // 판정 결과를 보여주는 UI

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        ResultPanel.SetActive(false);
        maxcombo = 0;
        JudgmentText.text = ""; // 초기에는 텍스트를 비움
    }

    private void Update()
    {
        foreach (Transform child in transform)
        {
            if (child.name == "ScoreText")
            {
                textMesh = child.GetComponent<TextMeshPro>();
                if (textMesh != null)
                {
                    textMesh.text = gamescore.ToString();
                }
                break;
            }
        }

        foreach (Transform child in transform)
        {
            if (child.name == "ComboText")
            {
                textMesh2 = child.GetComponent<TextMeshPro>();
                if (textMesh2 != null)
                {
                    textMesh2.text = combo.ToString();
                }
                break;
            }
        }

        if (spawner.currentTime >= endtime)
        {
            EndGame();
        }
    }

    public void ProcessJudgment(string judgment)
    {
        switch (judgment)
        {
            case "Perfect":
                score += 10;
                combo++;
                perfect_cnt++;
                ShowJudgmentText("PERFECT", new Color(0.5f, 0f, 0.5f));
                break;
            case "Great":
                score += 6;
                combo++;
                great_cnt++;
                ShowJudgmentText("GREAT", new Color(0.53f, 0.81f, 0.98f));
                break;
            case "Good":
                score += 2;
                combo++;
                good_cnt++;
                ShowJudgmentText("GOOD", new Color(0.68f, 1f, 0.18f));
                break;
            case "Bad":
                score += 2;
                combo = 0;
                bad_cnt++;
                ShowJudgmentText("BAD", new Color(1f, 1f, 0f));
                break;
            case "Hit":
                score++;
                combo++;
                break;
        }

        gamescore = (uint)score * 1000000u / (uint)maxscore;

        if (combo > maxcombo)
        {
            maxcombo = combo;
        }
    }

    public void ProcessMiss()
    {
        combo = 0;
        miss_cnt++;
        ShowJudgmentText("MISS", new Color(0.5f, 0.5f, 0.5f));
    }

    private void ShowJudgmentText(string judgment, Color color)
    {
        JudgmentText.text = judgment;
        JudgmentText.color = color;
        StartCoroutine(ClearJudgmentText());
    }

    private IEnumerator ClearJudgmentText()
    {
        yield return new WaitForSeconds(1f); // 1초 후에 텍스트 비우기
        JudgmentText.text = "";
    }

    private void EndGame()
    {
        GameManager.Instance.ShowResults((int)gamescore, songname, perfect_cnt, great_cnt, good_cnt, bad_cnt, miss_cnt, maxcombo);
        Time.timeScale = 0;
    }
}

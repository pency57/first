using UnityEngine;
using System.Collections;


public class NoteMovement : MonoBehaviour
{
    public float speed; // 노트 내려오는 속도
    public float xpos;
    private bool isJudged = false; // 판정 유무

    private void Update()
    {
        // 아래로 이동
        transform.Translate(Vector3.down * speed * Time.deltaTime);

        // 화면 아래로 사라지면 삭제
        if (!isJudged && transform.position.y < -18f)
        {
            isJudged = true;
            ScoreManager.Instance.ProcessMiss();
            Destroy(gameObject);
        }

        // xpos 값에 따라 눌러야 하는 키를 결정
        if (!isJudged)
        {
            if (xpos == -6.75f) // Q 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorOne && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    HandleNoteJudgement();
                }
            }
            else if (xpos == -2.25f) // W 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorTwo && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    HandleNoteJudgement();
                }
            }
            else if (xpos == 2.25f) // E 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorThree && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    HandleNoteJudgement();
                }
            }
            else if (xpos == 6.75f) // R 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorFour && ArduinoSerialReceiver.Instance.paddleSensorPressed)
                {
                    HandleNoteJudgement();
                }
            }
        }
    }

private void HandleNoteJudgement()
    {
        float yPos = transform.position.y;

        if (Mathf.Abs(yPos + 14.4f) <= 0.05f * speed)
        {
            isJudged = true;
            ScoreManager.Instance.ProcessJudgment("Perfect");
            StartCoroutine(FadeOutAndDestroy());
        }
        else if (Mathf.Abs(yPos + 14.4f) <= 0.09f * speed)
        {
            isJudged = true;
            ScoreManager.Instance.ProcessJudgment("Great");
            StartCoroutine(FadeOutAndDestroy());
        }
        else if (Mathf.Abs(yPos + 14.4f) <= 0.13f * speed)
        {
            isJudged = true;
            ScoreManager.Instance.ProcessJudgment("Good");
            StartCoroutine(FadeOutAndDestroy());
        }
        else if (Mathf.Abs(yPos + 14.4f) <= 0.17f * speed)
        {
            isJudged = true;
            ScoreManager.Instance.ProcessJudgment("Bad");
            StartCoroutine(FadeOutAndDestroy());
        }
        else
        {
            // Debug.Log("입력 안 됨! Y position: " + yPos);
        }
    }

    private IEnumerator FadeOutAndDestroy()
    {
        float duration = 0.1f; // 애니메이션 지속 시간
        float elapsedTime = 0f;
        speed = 0;

        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        Color originalColor = spriteRenderer.color;
        Vector3 originalScale = transform.localScale;

        while (elapsedTime < duration)
        {
            elapsedTime += Time.deltaTime;
            float t = elapsedTime / duration;

            // 크기를 점점 키움
            transform.localScale = Vector3.Lerp(originalScale, originalScale * 2f, t);

            // 투명도를 줄임
            Color newColor = originalColor;
            newColor.a = Mathf.Lerp(originalColor.a, 0, t);
            spriteRenderer.color = newColor;

            // 색을 밝게 만듦 (예: 흰색으로 점점 변환)
            spriteRenderer.color = Color.Lerp(originalColor, Color.white, t);

            yield return null;
        }

        // 애니메이션이 끝난 후 객체 삭제
        Destroy(gameObject);
    }
}

//60에서 -14.4로 이동 (-8.65가 판정선)
using UnityEngine;
using System.Collections;

public class NoteMovement2 : MonoBehaviour
{
    public float speed; // 노트 내려오는 속도
    public float height;
    public float xpos;
    private bool isJudged = false; // 판정 유무
    private bool isLongNoteHeld = false; // 롱 노트가 눌려 있는지 여부
    private SpriteRenderer spriteRenderer; // 노트의 색상을 제어할 SpriteRenderer
    private float whammyBarReleasedTime = 0f; // WhammyBarReleased 상태가 지속된 시간

    void Start()
    {
        // SpriteRenderer 컴포넌트를 가져옴
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer == null)
        {
            Debug.LogError("SpriteRenderer를 찾을 수 없습니다. 이 스크립트는 SpriteRenderer가 있는 오브젝트에 부착되어야 합니다.");
        }
    }

    private void Update()
    {
        // 아래로 이동
        transform.Translate(Vector3.down * speed * Time.deltaTime);

        // 화면 아래로 사라지면 삭제
        if (!isJudged && transform.position.y < -25f + height / 2)
        {
            isJudged = true;
            ScoreManager.Instance.ProcessMiss();
            Destroy(gameObject);
        }

        // xpos 값에 따라 눌러야 하는 키를 결정
        if (!isJudged)
        {
            if (xpos == -6.75f) // Q 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorOne && ArduinoSerialReceiver.Instance.WhammyBarPressed)
                {
                    HandleNoteJudgement();
                }
            }
            else if (xpos == -2.25f) // W 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorTwo && ArduinoSerialReceiver.Instance.WhammyBarPressed)
                {
                    HandleNoteJudgement();
                }
            }
            else if (xpos == 2.25f) // E 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorThree && ArduinoSerialReceiver.Instance.WhammyBarPressed)
                {
                    HandleNoteJudgement();
                }
            }
            else if (xpos == 6.75f) // R 키에 해당하는 xpos 범위
            {
                if (ArduinoSerialReceiver.Instance.TouchSensorFour && ArduinoSerialReceiver.Instance.WhammyBarPressed)
                {
                    HandleNoteJudgement();
                }
            }
        }

        if (isLongNoteHeld)
        {
            HeldNoteJudgement();
        }
    }

    private void HandleNoteJudgement()
    {
        float yPos = transform.position.y;

        if (Mathf.Abs(yPos - (-14.4f + height / 2)) <= 0.06f * speed)
        {
            isJudged = true; // 판정 처리
            isLongNoteHeld = true;
            ScoreManager.Instance.ProcessJudgment("Perfect");
        }
        else if (Mathf.Abs(yPos - (-14.4f + height / 2)) <= 0.11f * speed)
        {
            isJudged = true; // 판정 처리
            isLongNoteHeld = true;
            ScoreManager.Instance.ProcessJudgment("Great");
        }
        else if (Mathf.Abs(yPos - (-14.4f + height / 2)) <= 0.16f * speed)
        {
            isJudged = true; // 판정 처리
            isLongNoteHeld = true;
            ScoreManager.Instance.ProcessJudgment("Good");
        }
        else if (Mathf.Abs(yPos - (-14.4f + height / 2)) <= 0.21f * speed)
        {
            isJudged = true; // 판정 처리
            isLongNoteHeld = true;
            ScoreManager.Instance.ProcessJudgment("Bad");
        }
    }

    private void HeldNoteJudgement()
    {
        float yPos = transform.position.y;
        if (spriteRenderer != null)
        {
            // RGB 값을 특정 색상으로 설정 (예: 밝은 색상)
            spriteRenderer.color = new Color(
                0.7f, // R 값 (0~1 사이 값)
                0.99f, // G 값 (0~1 사이 값)
                0.7f, // B 값 (0~1 사이 값)
                spriteRenderer.color.a // 기존 투명도 유지
            );
        }

        if (!ArduinoSerialReceiver.Instance.WhammyBarPressed)
        {
            if (whammyBarReleasedTime == 0f)
            {
                // WhammyBar가 처음 놓였을 때 시간 기록 시작
                whammyBarReleasedTime = Time.time;
            }

            // WhammyBar가 놓인 상태가 0.15초 이상 지속되었는지 확인
            if (Time.time - whammyBarReleasedTime >= 0.15f)
            {
                ScoreManager.Instance.ProcessMiss();
                Destroy(gameObject);
            }
        }
        else
        {
            // WhammyBar가 다시 눌리면 타이머 초기화
            whammyBarReleasedTime = 0f;
        }

        if (Mathf.Abs(yPos - (-14.4f - height / 2)) <= 0.21f * speed)
        {
            ScoreManager.Instance.ProcessJudgment("Perfect");
            Destroy(gameObject); // 노트 삭제
        }
    }
}

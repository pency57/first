using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using SQLite;
using UnityEngine.SceneManagement;

public class ScoreEntry
{
    [PrimaryKey]
    public string Nickname { get; set; }
    public string Music { get; set; }
    public int PERFECT { get; set; }
    public int GREAT { get; set; }
    public int GOOD { get; set; }
    public int BAD { get; set; }
    public int MISS { get; set; }
    public int Max_combo { get; set; }
    public int Total_score { get; set; }
}

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public GameObject ResultPanel; // 결과 화면 패널
    public TextMeshProUGUI ResultText; // 결과 텍스트 표시
    private SQLiteConnection db;

    [Header("Nickname Input UI")]
    public GameObject NicknamePanel; // 닉네임 입력 패널
    public TMP_InputField NicknameInputField; // 닉네임 입력 필드
    public string PlayerNickname = ""; // 기본 닉네임
    private string connectionString = Application.dataPath + "/persistentDataPath"; // SQLite DB 경로

    // 게임 결과 데이터를 저장할 임시 변수
    private int tempScore;
    private string tempSongName;
    private int tempPerfect, tempGreat, tempGood, tempBad, tempMiss, tempMaxCombo;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        ResultPanel.SetActive(false); // 결과 화면 비활성화
        NicknamePanel.SetActive(false); // 닉네임 입력 화면 비활성화

        // 데이터베이스 파일 경로 설정
        // string dbPath = Application.persistentDataPath + "/RecordData.sqlite";
        string dbPath = Application.persistentDataPath + "/RecordData.sqlite";
        Debug.Log($"Database Path: {dbPath}");
        db = new SQLiteConnection(dbPath);
        db.CreateTable<ScoreEntry>(); // 테이블 생성

        // Enter 키를 누르면 ConfirmNickname 호출
        NicknameInputField.onSubmit.AddListener(ConfirmNickname);
    }

    private void ConfirmNickname(string input)
    {
        if (!string.IsNullOrEmpty(input))
        {
            PlayerNickname = input; // 닉네임 저장
            NicknamePanel.SetActive(false); // 닉네임 입력 화면 비활성화
            Debug.Log($"Nickname confirmed: {PlayerNickname}");
            AddScore(PlayerNickname, tempSongName, tempPerfect, tempGreat, tempGood, tempBad, tempMiss, tempMaxCombo, tempScore);

            // DB에 저장 후 다른 씬으로 이동
            StartCoroutine(LoadNextScene());
        }
    }

    public void ShowResults(int score, string songname, int perfect, int great, int good, int bad, int miss, int maxCombo)
    {
        ResultPanel.SetActive(true); // 결과 화면 표시
        NicknamePanel.SetActive(true); // 닉네임 입력 화면 활성화

        ResultText.text = $"Game Over!\n\n" + $"Score: {score}\n" +
                          $"Song: {songname}\n" +
                          $"Perfect: {perfect}\n" +
                          $"Great: {great}\n" +
                          $"Good: {good}\n" +
                          $"Bad: {bad}\n" +
                          $"Miss: {miss}\n" +
                          $"Max Combo: {maxCombo}";

        // 임시 변수에 결과 저장
        tempScore = score;
        tempSongName = songname;
        tempPerfect = perfect;
        tempGreat = great;
        tempGood = good;
        tempBad = bad;
        tempMiss = miss;
        tempMaxCombo = maxCombo;
        // Debug.Log("결과 변수 기록");
    }

    public void AddScore(string nickname, string music, int perfect, int great, int good, int bad, int miss, int maxCombo, int totalScore)
    {
        ScoreEntry newScore = new ScoreEntry
        {
            Nickname = nickname,
            Music = music,
            PERFECT = perfect,
            GREAT = great,
            GOOD = good,
            BAD = bad,
            MISS = miss,
            Max_combo = maxCombo,
            Total_score = totalScore
        };

        db.Insert(newScore); // 행 추가
        Debug.Log("Score added to database.");
    }

    private IEnumerator LoadNextScene()
    {
        Debug.Log("씬 넘기기 대기 중");
        yield return null; // 2초 대기 (연출용)
        Debug.Log("씬 넘기기 실행준비");
        SceneManager.LoadScene("mainMenu"); // 이동할 씬 이름 지정
    }
}
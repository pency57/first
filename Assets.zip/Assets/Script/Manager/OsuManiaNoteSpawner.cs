using UnityEngine;
using System.Collections;

public class OsuManiaNoteSpawner : MonoBehaviour
{
    public OsuManiaNoteParser parser; // 노트 데이터를 관리하는 스크립트
    public GameObject notePrefab;    // 노트 프리팹
    public GameObject notePrefab2;   // 노트 프리팹
    public GameObject notePrefab3;   // 노트 프리팹
    public Transform noteParent;     // 노트 부모 오브젝트 (Optional)
    private float noteSpeed = SceneData.NoteSpeed;
    public float currentTime;

    public AudioSource audioSource;  // 음악을 재생할 AudioSource
    private AudioClip musicClip;      // 재생할 음악 파일
    private float musicStartTime;     // 음악 시작 시간 (밀리초 단위)

    private void Start()
    {
        currentTime = -5000f;
        musicClip = Resources.Load<AudioClip>(SceneData.MusicClip);
        musicStartTime = SceneData.StartT + SceneData.OffSet;

        if (musicClip == null)
        {
            Debug.LogError($"AudioClip '{SceneData.MusicClip}' not found in Resources folder!");
        }

        // 음악이 시작될 특정 시간에 맞춰 음악을 재생하도록 설정
        if (audioSource != null && musicClip != null)
        {
            audioSource.clip = musicClip;
            audioSource.volume = 1.0f;

            // 음악 시작 시간을 지연시켜서 음악을 특정 시간에 시작
            StartCoroutine(PlayMusicAtTime(musicStartTime));
        }
        else
        {
            Debug.LogError("AudioSource or MusicClip is not assigned.");
        }

        // 파싱된 데이터를 확인
        if (parser == null || parser.notes.Count == 0)
        {
            Debug.LogError("Note data is not available. Please check the parser.");
        }
    }

    private void Update()
    {
        currentTime += Time.deltaTime * 1000; // 현재 시간 (ms)

        // 노트를 생성할 시간인지 확인
        for (int i = parser.notes.Count - 1; i >= 0; i--)
        {
            if (currentTime >= parser.notes[i].StartTime)
            {
                SpawnNote(parser.notes[i]);
                parser.notes.RemoveAt(i); // 생성된 노트는 리스트에서 제거
            }
        }
    }

    private void SpawnNote(OsuManiaNoteParser.NoteInfo noteInfo)
    {
        // noteSpeed = 30f;

        // 노트 생성 및 초기 위치 설정
        if (noteInfo.EndTime == 0)
        {
            GameObject newNote = Instantiate(notePrefab, noteParent);
            float xPosition = GetXPosition(noteInfo.XCoordinate);
            newNote.transform.position = new Vector3(xPosition, 60f, 20f);
            NoteMovement movement = newNote.AddComponent<NoteMovement>();
            movement.speed = noteSpeed;
            movement.xpos = xPosition;
        }
        else if (noteInfo.HitCount == 0)
        {
            GameObject newNote = Instantiate(notePrefab2, noteParent);
            float xPosition = GetXPosition(noteInfo.XCoordinate);
            float noteHeight = GetNoteHeight(noteInfo);
            newNote.transform.localScale = new Vector3(2f, noteHeight, 1f);
            newNote.transform.position = new Vector3(xPosition, 60f + noteHeight / 2, 20f);
            NoteMovement2 movement = newNote.AddComponent<NoteMovement2>();
            movement.speed = noteSpeed;
            movement.height = noteHeight;
            movement.xpos = xPosition;
        }
        else
        {
            GameObject newNote = Instantiate(notePrefab3, noteParent);
            float xPosition = GetXPosition(noteInfo.XCoordinate);
            float noteHeight = GetNoteHeight(noteInfo);
            newNote.transform.localScale = new Vector3(2f, noteHeight, 1f);
            newNote.transform.position = new Vector3(xPosition, 60f + noteHeight / 2, 20f);

            foreach (Transform child in newNote.transform)
            {
                if (child.name == "HitText")
                {
                    child.localScale = new Vector3(2f / newNote.transform.localScale.x, 2f / newNote.transform.localScale.y, 1f / newNote.transform.localScale.z);
                    child.position = new Vector3(newNote.transform.position.x, newNote.transform.position.y + noteHeight / 2 - 1.5f, newNote.transform.position.z);
                }
            }

            NoteMovement3 movement = newNote.AddComponent<NoteMovement3>();
            movement.speed = noteSpeed;
            movement.height = noteHeight;
            movement.hits = noteInfo.HitCount;
            movement.xpos = xPosition;
        }
    }

    private float GetXPosition(int xCoordinate)
    {
        switch (xCoordinate)
        {
            case 64: return -6.75f;
            case 192: return -2.25f;
            case 320: return 2.25f;
            case 448: return 6.75f;
            default: return 0f;
        }
    }

    private float GetNoteHeight(OsuManiaNoteParser.NoteInfo noteInfo)
    {
        float noteDuration = noteInfo.EndTime - noteInfo.StartTime;
        return noteSpeed * noteDuration / 1000f;
    }

    private IEnumerator PlayMusicAtTime(float startTime)
    {
        // 지정된 시간만큼 대기한 후 음악을 시작
        Debug.Log("음악 재생 준비!");
        yield return new WaitForSeconds(startTime / 1000f); // startTime을 초 단위로 변환
        Debug.Log("음악 재생 시작!" + startTime);
        if (!audioSource.isPlaying)  // 음악이 재생 중이 아니라면
        {
            audioSource.Play();

        }
    }
}

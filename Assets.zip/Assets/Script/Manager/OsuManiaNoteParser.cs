using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class OsuManiaNoteParser : MonoBehaviour
{
    private string fileName = SceneData.FileName; // StreamingAssets 폴더 내 파일 이름
    [SerializeField]
    public List<NoteInfo> notes = new List<NoteInfo>();

    private void Start()
    {
        ParseNoteFile();
    }

    private void ParseNoteFile()
    {
        string filePath = Path.Combine(Application.streamingAssetsPath, fileName);

        try
        {
            if (!File.Exists(filePath))
            {
                Debug.LogError($"File not found at: {filePath}: +{fileName}");
                return;
            }

            string[] lines = File.ReadAllLines(filePath);
            bool hitObjectsSection = false;

            foreach (var line in lines)
            {
                if (line.StartsWith("[HitObjects]"))
                {
                    hitObjectsSection = true;
                    continue;
                }

                if (hitObjectsSection && !string.IsNullOrWhiteSpace(line))
                {
                    string[] parts = line.Split(',');
                    if (parts.Length >= 6)
                    {
                        try
                        {
                            int x = int.Parse(parts[0]);
                            int startTime = int.Parse(parts[2]);
                            int endTime = parts[5].Contains(":") ? int.Parse(parts[5].Split(':')[0]) : 0;
                            int hitCount = parts[5].Contains(":") ? int.Parse(parts[5].Split(':')[1]) : 0;

                            notes.Add(new NoteInfo
                            {
                                XCoordinate = x,
                                StartTime = startTime,
                                EndTime = endTime,
                                HitCount = hitCount
                            });
                        }
                        catch (Exception parseException)
                        {
                            Debug.LogError($"Error parsing line '{line}': {parseException.Message}");
                        }
                    }
                }
            }

            // 노트 정보 출력
            // foreach (var note in notes)
            // {
            //     // Debug.Log(note);
            // }
        }
        catch (Exception e)
        {
            Debug.LogError($"Error parsing file: {e.Message}");
        }
    }

    [System.Serializable]
    public class NoteInfo
    {
        public int XCoordinate;
        public int StartTime;
        public int EndTime;
        public int HitCount;

        public override string ToString()
        {
            return $"X: {XCoordinate}, Start: {StartTime}, End: {EndTime}, Hits: {HitCount}";
        }
    }
}

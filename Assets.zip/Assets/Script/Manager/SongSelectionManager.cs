using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class ImageCarousel : MonoBehaviour
{
    public RectTransform[] images; // 순환할 이미지들
    public Text rankingText; // 랭킹 정보를 표시할 Text
    private float transitionSpeed = 3000f; // 고정된 이동 속도

    private int currentIndex = 0; // 현재 선택된 이미지 인덱스
    private bool isTransitioning = false; // 애니메이션 중인지 확인

    private string selectedImageName = ""; // 선택된 이미지 이름
    private bool sceneDataUpdated = false;

    void Start()
    {
        InitializeCarousel();
        UpdateSceneData(currentIndex); // 초기 값 설정
    }

    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == "SongSelectionScene") // SongSelectionScene에서만 실행
        {
            InitializeCarousel();
            UpdateSceneData(currentIndex); // 씬 로드 시 SceneData 갱신
        }
        else if (scene.name == "GameScene") // GameScene에서 처리할 로직 추가
        {
            Debug.Log("GameScene 로드 완료!");
            // 필요에 따라 GameScene 관련 초기화 추가
        }
    }

    private void InitializeCarousel()
    {
        // currentIndex = 0; // 인덱스 초기화
        isTransitioning = false; // 애니메이션 상태 초기화

        // 이미지 초기 위치 설정
        for (int i = 0; i < images.Length; i++)
        {
            if (i == currentIndex)
            {
                images[i].anchoredPosition = Vector2.zero; // 중앙에 위치
            }
            else
            {
                images[i].anchoredPosition = new Vector2(Screen.width, 0); // 화면 밖 오른쪽
            }
        }
    }


    private IEnumerator MoveCarousel(int direction)
    {
        isTransitioning = true;

        int nextIndex = (currentIndex + direction + images.Length) % images.Length;

        RectTransform currentImage = images[currentIndex];
        RectTransform nextImage = images[nextIndex];

        nextImage.anchoredPosition = new Vector2(direction * Screen.width, 0);

        float totalDistance = Screen.width;
        float movedDistance = 0f;

        while (movedDistance < totalDistance)
        {
            float step = transitionSpeed * Time.deltaTime;
            movedDistance += step;

            currentImage.anchoredPosition += new Vector2(-direction * step, 0);
            nextImage.anchoredPosition += new Vector2(-direction * step, 0);

            yield return null;
        }

        currentImage.anchoredPosition = new Vector2(-direction * Screen.width, 0);
        nextImage.anchoredPosition = Vector2.zero;

        currentIndex = nextIndex;
        Debug.Log("현재 인덱스" + currentIndex);
        UpdateSceneData(currentIndex); // 인덱스 변경 시 SceneData 갱신

        isTransitioning = false;
    }

    private void UpdateSceneData(int index)
    {
        Debug.Log("!!!!!!");
        // 각 인덱스에 따라 SceneData를 설정
        switch (index)
        {
            case 0:
                SceneData.SongName = "Canon Rock";
                SceneData.MusicClip = "Canon Rock";
                SceneData.FileName = "canonrock.txt";
                SceneData.MaxScore = 4066;
                SceneData.NoteSpeed = 30f;
                SceneData.OffSet = 0;
                SceneData.StartT = 5000f + 852f + 68.65f * 1000f / SceneData.NoteSpeed -(800f);
                SceneData.EndT = 113042;
                break;

            case 1:
                SceneData.SongName = "Travel";
                SceneData.MusicClip = "Travel";
                SceneData.FileName = "travel.txt";
                SceneData.MaxScore = 2876;
                SceneData.NoteSpeed = 30f;
                SceneData.OffSet = 0;
                SceneData.StartT = 5000f + 852f + 68.65f * 1000f / SceneData.NoteSpeed -(800f);
                SceneData.EndT = 152000;
                break;

            case 2:
                Debug.Log("케이스 2 실행됨");
                SceneData.SongName = "Jingle Bell Rock";
                SceneData.MusicClip = "JingleBellRock";
                SceneData.FileName = "jinglebellrock.txt";
                SceneData.MaxScore = 2131;
                SceneData.NoteSpeed = 30f;
                SceneData.OffSet = 0f;
                SceneData.StartT = 5000f + 500f + 68.65f * 1000f / SceneData.NoteSpeed -(800f);
                SceneData.EndT = 132202;
                break;

            default:
                Debug.LogWarning("Invalid index for SceneData");
                break;
        }

        Debug.Log($"SceneData updated for index {index}: {SceneData.SongName}");
    }

    void Update()
    {
        // 왼쪽 이동: TouchSensorOne
        if (ArduinoSerialReceiver.Instance.TouchSensorOne && !isTransitioning)
        {
            StartCoroutine(MoveCarousel(-1));
        }

        // 오른쪽 이동: TouchSensorFour
        if (ArduinoSerialReceiver.Instance.TouchSensorFour && !isTransitioning)
        {
            StartCoroutine(MoveCarousel(1));
        }

        // 선택 처리: PaddleSensor
        if (ArduinoSerialReceiver.Instance.paddleSensorPressed && !sceneDataUpdated)
        {
            selectedImageName = images[currentIndex].gameObject.name;
            Debug.Log("선택된 이미지: " + selectedImageName);

            // SceneData 업데이트
            UpdateSceneData(currentIndex);
            sceneDataUpdated = true;
            // GameScene으로 전환
            SceneManager.LoadScene("GameScene");
        }
    }
}
